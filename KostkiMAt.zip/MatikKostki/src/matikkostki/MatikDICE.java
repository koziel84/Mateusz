/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matikkostki;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class MatikDICE {

    public static void main(String[] args) {
        Random generator = new Random();
        int odp = generator.nextInt(5) + 1;

        System.out.println("Zgadnij liczbe");
        Player player = new Player();
        

        int num1 = player.guess();
        while (odp != num1) {
            System.out.println(num1);
            System.out.println("Nie zgadles probuj dalej");
            num1 = player.guess();

        }
        System.out.println(num1);
        System.out.println("Wygrales " + player.getName());
    }

}
